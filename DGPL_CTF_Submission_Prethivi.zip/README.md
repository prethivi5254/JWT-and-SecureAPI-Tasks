# DGPL CTF Development Assignment — Submission

Candidate: **Prethivi V.S.**  
Date: **2025-08-28**

This archive contains both required tasks:

1. **JWT Security Task** (`jwt_security_task/`)
   - `jwt_attack_demo.py` → PoC for forging tokens with weak HS256 secrets; includes small dictionary guesser.
   - `research_report.pdf` → 1–2 page write‑up covering common JWT vulnerabilities and defenses with references.
   - `README.md` → setup & usage instructions.

2. **Secure API Task** (`secure_api_task/`)
   - `secure_api.py` → FastAPI app implementing `/register`, `/login`, `/profile` with proper JWT handling.
   - `requirements.txt` → to install dependencies.
   - `README.md` → run & test instructions (curl examples).
   - `DGPL_Secure_API.postman_collection.json` → optional for quick testing.

**Notes & Ethics**  
The PoC is strictly for educational use in a controlled lab. Do not target systems you do not own/operate or have explicit permission to test.

— Prethivi V.S.
