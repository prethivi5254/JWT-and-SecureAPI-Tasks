#!/usr/bin/env python3
"""
DGPL Secure API (CTF Task) — FastAPI reference implementation

Endpoints:
  • GET  /           -> simple landing JSON (so root doesn't 404)
  • GET  /healthz    -> liveness check
  • POST /register   -> create user (password hashed with bcrypt)
  • POST /login      -> authenticate & issue short-lived JWT (HS256)
  • GET  /profile    -> protected; requires Authorization: Bearer <JWT>
"""

import os
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict

from fastapi import FastAPI, HTTPException, Depends, Header
from pydantic import BaseModel, EmailStr, Field
from passlib.context import CryptContext
import jwt  # PyJWT

app = FastAPI(title="DGPL Secure API (CTF Task)")

# ---- Security/Config --------------------------------------------------------
pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

JWT_SECRET = os.environ.get("JWT_SECRET") or os.environ.get("JWT_SECRET_KEY")
if not JWT_SECRET or len(JWT_SECRET) < 32:
    import secrets
    JWT_SECRET = secrets.token_urlsafe(48)

JWT_ALG = os.environ.get("JWT_ALG", "HS256")
ACCESS_TTL_MIN = int(os.environ.get("ACCESS_TTL_MIN", "15"))
ISS = os.environ.get("JWT_ISS", "dgpl-secure-api")
AUD = os.environ.get("JWT_AUD", "dgpl-clients")

# In-memory store (demo only)
USERS: Dict[str, Dict] = {}

# ---- Models -----------------------------------------------------------------
class RegisterReq(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)

class LoginReq(BaseModel):
    email: EmailStr
    password: str

# ---- Helpers ----------------------------------------------------------------
def hash_password(pw: str) -> str:
    return pwd_ctx.hash(pw)

def verify_password(pw: str, hashed: str) -> bool:
    return pwd_ctx.verify(pw, hashed)

def issue_token(email: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": email,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=ACCESS_TTL_MIN)).timestamp()),
        "iss": ISS,
        "aud": AUD,
        "role": USERS[email].get("role", "user"),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

def require_auth(authorization: Optional[str] = Header(None)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")
    token = authorization.split(None, 1)[1]
    try:
        data = jwt.decode(
            token,
            JWT_SECRET,
            algorithms=[JWT_ALG],
            audience=AUD,
            issuer=ISS,
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError as e:
        raise HTTPException(status_code=401, detail=f"Invalid token: {str(e)}")

    email = data.get("sub")
    if not email or email not in USERS:
        raise HTTPException(status_code=401, detail="User not found")
    return email, data

# ---- Routes -----------------------------------------------------------------
@app.get("/")
def root():
    return {
        "ok": True,
        "service": "DGPL Secure API",
        "docs": "/docs",
        "endpoints": ["/register (POST)", "/login (POST)", "/profile (GET, Bearer)"],
    }

@app.get("/healthz")
def healthz():
    return {"status": "ok", "time": datetime.now(timezone.utc).isoformat()}

@app.post("/register")
def register(req: RegisterReq):
    if req.email in USERS:
        raise HTTPException(status_code=400, detail="User already exists")
    USERS[req.email] = {
        "email": req.email,
        "password": hash_password(req.password),
        "role": "user",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    return {"ok": True, "message": "Registered", "email": req.email}

@app.post("/login")
def login(req: LoginReq):
    u = USERS.get(req.email)
    if not u or not verify_password(req.password, u["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = issue_token(req.email)
    return {"access_token": token, "token_type": "bearer", "expires_in_minutes": ACCESS_TTL_MIN}

@app.get("/profile")
def profile(ctx=Depends(require_auth)):
    email, claims = ctx
    u = USERS[email]
    return {"email": email, "role": u["role"], "created_at": u["created_at"], "claims": claims}

# ---- Run via `python secure_api.py` -----------------------------------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "secure_api:app",
        host="127.0.0.1",
        port=int(os.getenv("PORT", "8000")),
        reload=True,
    )
