# Secure API Task — FastAPI Implementation

**Author:** Prethivi V.S.  
**Date:** 2025-08-28

Implements the required endpoints with proper JWT signing (HS256 by default), short‑lived tokens, and input validation.

## Endpoints
- `POST /register` → email, password (hashed with bcrypt)
- `POST /login` → returns `access_token` (JWT, HS256, 15 min expiry by default)
- `GET /profile` → protected; requires `Authorization: Bearer <token>`

## Setup

```bash
python -m venv .venv && source .venv/bin/activate  # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
export JWT_SECRET="$(python - <<'PY'
import secrets; print(secrets.token_urlsafe(64))
PY)"
export ACCESS_TTL_MIN=15
uvicorn secure_api:app --reload
```

## Test (curl)

```bash
# Register
curl -s -X POST http://127.0.0.1:8000/register -H "Content-Type: application/json"   -d '{"email":"alice@example.com","password":"StrongPassw0rd!"}'

# Login
TOKEN=$(curl -s -X POST http://127.0.0.1:8000/login -H "Content-Type: application/json"   -d '{"email":"alice@example.com","password":"StrongPassw0rd!"}' | python -c "import sys, json; print(json.load(sys.stdin)['access_token'])")

# Access profile
curl -s http://127.0.0.1:8000/profile -H "Authorization: Bearer $TOKEN" | jq
```

## Security notes
- HS256 keys **must be random and ≥32 bytes**. Set via `JWT_SECRET`. Do **not** use defaults in production.
- Tokens expire quickly (default 15 min). Consider refresh tokens if needed.
- `iss` and `aud` are validated. Adjust with env `JWT_ISS`, `JWT_AUD` to match your deployment.
- Store tokens securely (HTTPOnly cookies recommended when used with browsers) and protect against XSS/CSRF.

## Optional (RS256)
For asymmetric signing, set `JWT_ALG=RS256` and provide `JWT_PRIVATE_KEY`/`JWT_PUBLIC_KEY` via a small extension. This minimal submission ships HS256 for portability per task guidelines.
